﻿var domicileApp = angular.module("domicileApp", ["ngRoute", "ngMaterial"]);

domicileApp.config(function($routeProvider) {
    $routeProvider
        .when("/services",
        {
            templateUrl: "/Content/Partials/services.html",
            controller: "ServicesController"
        });
});

domicileApp.controller("ServicesController",
    function ($scope, $http, $mdDialog) {

        $http({ method: "GET", url: "/api/services" })
            .then(function(response) {
                $scope.services = response.data;
            }, function(error) {
                console.log("Failed getting services", error);
            });

        $scope.updateService = function(service, serviceVariablesForm) {
            $http({ method: "POST", url: "/api/services", data: service })
                .then(function(data, status) {
                    $scope.services.push(data);
                });
        };

        
    });